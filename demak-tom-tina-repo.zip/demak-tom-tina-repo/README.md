# DEMAK Recherche-Team: Tom und Tina

Zwei getrennte KI-Agenten für die Neukunden- und Messerecherche (Elektronik-Verguss, Klebe- und Dosieranwendungen):

| Agent | Datei | Aufgabe |
|---|---|---|
| Tom | `.claude/agents/01-recherche-mitarbeiter.md` | recherchiert Firmen, schreibt `tom_batch_NN.md` (Felder 1 bis 17) |
| Tina | `.claude/agents/02-recherche-pruefer.md` | prüft unabhängig, öffnet Quellen im Browser, vergibt die Ampel |

Dazu: `regeln_tom_tina.md` (gemeinsame Regeln), `fehlerlog_lehren.md` (Lehren aus Fehlern), `goldstandard_testset.md` (Vergleich mit Jeys manueller Prüfung), `wettbewerber_referenzen.md` (bekannte Referenzkunden der Wettbewerber), `efx_verguss_wissensbasis.md`, Skripte `crm_abgleich.py` und `batch_check.py`, `lauf_beispiele/` (ein Testlauf Rhein-Neckar).

## Einrichtung in Cowork / Claude Code mit GitHub

1. Neues **privates** Repository anlegen (Inhalt nennt Kundenstatus und Wettbewerbsdaten) und diesen Ordner hochladen oder pushen.
2. Repository in Cowork bzw. Claude Code als Projekt öffnen. Die Agenten unter `.claude/agents/` werden automatisch erkannt, `CLAUDE.md` liefert den Kontext.
3. Lokal (nicht im Repo) die CRM-Exporte ablegen, siehe `daten_lokal/README.md`.
4. Python 3 wird für die Skripte gebraucht (nur Standardbibliothek). Für die Browserprüfung muss Chrome mit der Claude-Erweiterung verbunden sein.

## Benutzung

- Suche starten, z. B.: "Tom soll 10 neue Firmen im Raum Rhein-Neckar/Darmstadt, Elektronik, recherchieren." Danach Tina als eigenen Agenten mit nur `tom_batch_NN.md` starten.
- Ampel: Grün (Fertigung DE/AT/NL belegt und Verguss Hoch/Mittel), Gelb (mit Nachrecherche-Auftrag), Rot (Ausschluss oder gleiche Firma im CRM).
- Nach jeder manuellen Prüfung durch Jey: Ergebnis in `goldstandard_testset.md` und Fehler in `fehlerlog_lehren.md` eintragen.

## Nicht im Repo

CRM-Exporte, Kontaktlisten, E-Mail-Entwürfe, LinkedIn-Zwischenstände (siehe `.gitignore`).
