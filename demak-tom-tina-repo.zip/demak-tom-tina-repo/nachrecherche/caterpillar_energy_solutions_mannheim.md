# Nachrecherche Caterpillar Energy Solutions GmbH, Mannheim (2026-10-14)

Frage: Herstellwerk oder nur Endfertigung? Wo entstehen Zündsysteme, Steuerungen, Sensorik?

## Belegt
- Mannheim ist Sitz und Produktionsstandort: "production base" (caterpillar-energy-solutions.de/en/contact-locations/); Mannheim zum "global Gas Center of Excellence" ausgebaut, Entwicklung und Produktion gebündelt, "In-house manufacturing of all key components" (.../success-factors/operations/). Abruf 2026-10-14, WebFetch-Zusammenfassung, im Browser bestätigt von Tina nur für Operations-Seite.
- caterpillar.com (Germany footprint): Mannheim "development and production of large engines and generators", als Fertigungsstandort geführt. Stufe S.
- Produktseite: Cat-Gasmotoren "produced in Mannheim and Lafayette (US)". Aussage zu Kiel/Rostock bei MWM-Motoren unklar (Kiel = Caterpillar Motoren GmbH & Co. KG, Mittelschnellläufer, andere Gesellschaft); nicht verwerten ohne Browserprüfung.
- Handelsregister: Mannheim HRB 703305.

## Nicht belegt
- Keine Quelle sagt, wo Zündsysteme, Motorsteuerung (TEM/TPEM), Sensorik, Schaltschränke oder Generatorwicklung gefertigt werden. Weder Firmenseiten noch Stellenanzeigen (nur Mechatroniker/Industriemechaniker/Servicetechniker, Ausbildung Elektrotechnik) liefern einen Hinweis auf Elektronikfertigung oder Verguss in Mannheim.
- Marktindiz: MWM-Retrofit-Zündsysteme kommen von Drittanbietern (z. B. MOTORTECH, Celle; AVAT) – deutet auf Zukauf von Teilen der Elektronik hin (Stufe S).

## Bewertung
- Fertigung Mannheim: Hoch (V). Es ist ein Herstellwerk für Motoren und Gensets, keine reine Endfertigung.
- Verguss: Mittel (A). Wahrscheinlich Generatorwicklung/Genset-Elektrik und zugekaufte Elektronik; ein Verguss am Standort selbst ist nicht belegt.
- Ampel bleibt Grün nach Tabellenzeile 4, aber Mail-Aussagen nur allgemein ("Gasmotoren und Gensets"), keine Behauptung zu Zündmodul-Verguss.
- Offen (Jey/Telefon): Montage der Steuer- und Schaltschränke in Mannheim? Eigene Wicklungs-/Vergussprozesse im Generatorbau? (Generatoren: Herkunft ungeklärt)
