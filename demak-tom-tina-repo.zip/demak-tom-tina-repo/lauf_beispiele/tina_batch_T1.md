# tina_batch_T1 (Tina, Stufe 2, Testlauf Version 2, Verifikation 2026-10-14)

Eingabe: nur tom_batch_T1.md (Toms Rechercheweg unbekannt). Eigener Chrome-Tab, nur lesend, Cookie-Banner abgelehnt, kein Captcha, keine Login-Wand; Tab am Ende geschlossen.
CRM: crm_abgleich.py am 2026-10-14 für alle 8 Firmen inkl. Konzern-, Alt- und Kurznamen (u. a. HBM, Spectris, LAB14, RSBG, Caterpillar Inc., Deere & Company, F. Hoffmann-La Roche, Amperfied). Ein Treffer: "HBM" (bekannte_firmen_DE-AT-NL.txt Z. 989), von Tom übersehen.
Web: Browser und Google Patents verfügbar. Espacenet nur für HBK selbst wiederholt; DEPATISnet nicht erneut gefahren (siehe Einschränkungen).

## 1) Hottinger Brüel & Kjaer GmbH (HBK), Darmstadt
1. Firma: Hottinger Brüel & Kjær GmbH (HBK; Altname Hottinger Baldwin Messtechnik GmbH, Marke HBM), Darmstadt
2. Segment: Electrical Insulation / E-Mobility Potting (Sensoren, Wägezellen, Kraft-/Drehmomentaufnehmer, Messelektronik)
3. Gebiet: Rest Deutschland+Niederlande (Hessen)
4. Sitz und Fertigungsort: Im Tiefen See 45, D-64293 Darmstadt (Sitz, Werk laut hbm.com). Konzern mit Werken USA, China; Portugal und Waalwijk (NL) als Entwicklungsstandorte.
5. Website: https://www.hbkworld.com (Altmarke https://www.hbm.com)
6. Was wird gebaut: Mess- und Prüftechnik, Wägezellen, Kraftaufnehmer, Messverstärker, Datenerfassung (Stufe V, hbm.com). Typisch vergossen: Kabelanschlusseinheit für Wägezellen und Kraftaufnehmer mit Vergussmasse (Stufe V, eigenes Patent DE10350724B4, Epoxidharz), Aufnehmer-Elektronik und Messverstärker-Netzteile (Stufe A).
7. Fertigung DE/AT/NL: Hoch, Stufe V. hbm.com nennt Darmstadt "Global HBM Headquarters for R&D, Production, Services" mit drei Hauptfabriken (DE, USA, CN). Konzern mit mehreren Werken: Stufe V liegt vor; Zuordnung einzelner Produktlinien zu Darmstadt nicht einzeln belegt (A).
8. Verguss/Bonding (höchstes Bauteil): Hoch, Stufe V. Bauteile: Kabelanschlusseinheit Wägezelle/Kraftaufnehmer Hoch (V, Patent, aber Rechtsstand erloschen); DMS-Aufnehmer/Sensoren rauer Einsatz Hoch (A, Block A Sensoren); Messverstärker-Elektronik Mittel (A); Gehäusedichtungen Mittel (A).
9. Patentrecherche: Tina (a) Google Patents, DE10350724B4 im Browser geöffnet: Anmelder Hottinger Baldwin Messtechnik GmbH, jetzt Hottinger Bruel & Kjaer GmbH; Anspruch 1 mit Vergussmasse (14); Status "Expired - Fee Related" (R119 erloschen wegen nicht gezahlter Jahresgebühr, 2023-05-03; Tom nannte "erteilt" ohne Erlöschen). Zitiert von DE102005033391B4 "Kabelabdichtungshülse" (HBM, 2007) und DE102024004436A1 "Verfahren zur Herstellung einer Kabeldurchführung" (HBK GmbH, Anmeldung 2024-12-28, laut Zitationsliste veröffentlicht 2026-07-02; Inhalt nicht gelesen). (b) Espacenet, pa="Hottinger" AND ctxt="Vergussmasse": DE10350724A1 (Anmelder Hottinger Messtechnik Baldwin, 2005-06-02) als Treffer bestätigt. Toms übrige Treffer (EP0211144A2, DE3528510, CN108709492A) und DEPATISnet nicht erneut geprüft (Stufe S).
10. Einstufung Tom: interessant
11. Ampel (nur Tina): GELB, Tabellenzeile 3 (CRM-Bezug, Einheit unklar). Im CRM steht "HBM" (bekannte_firmen_DE-AT-NL.txt Z. 989, nur Land DE), das ist die Altmarke dieser Firma. Ob es dieselbe Einheit ist, ist aus dem Export nicht erkennbar; bei Identität wäre es Rot nach E5 (Bestandskontakt).
12. CRM-Status: unklar (CRM-Schreibweise "HBM" [DE], Z. 989); Tom meldete fälschlich "neu"
13. Nachrecherche-Auftrag und Aktion: Frage: Ist der CRM-Eintrag "HBM" (Z. 989) die Hottinger Baldwin Messtechnik/HBK GmbH in Darmstadt? Nachsehen: Kundendatenbank/xlsx (Ort, Ansprechpartner, "Verifiziert am") durch Jey. Bei Ja: Rot (E5), Bestandskontakt pflegen; bei Nein (anderer HBM-Betrieb): Grün (Fertigung V, Verguss Hoch). Aktion: Jey (Datenbankzugriff nötig, nicht per Web lösbar).
14. Quellen:
- https://www.hbm.com/7458/engineering-sites/ , Zitat: „Three main factories of HBM - in Germany, the USA and China“ (Browser gelesen, Abruf 2026-10-14)
- https://www.hbkworld.com/en/trust-centre/imprint , Zitat: „Im Tiefen See 45, D-64293 Darmstadt, Germany“ (Browser gelesen, Abruf 2026-10-14)
- https://patents.google.com/patent/DE10350724B4/de , Zitat: „vollständig mit einer Vergussmasse (14) umschlossen sind“ (Anspruch 1, Browser gelesen, Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja für alle drei. Toms Wortlaut „zur Abdichtung vollständig mit einer Vergußmasse (14) umschlossen ist“ stand so auf der B4-Seite nicht (Schreibweise/Satzbau), Aussage inhaltlich bestätigt.
15. Größe/Umsatz: unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Toms Suchen nicht wiederholt; Tina: wettbewerber_referenzen.md per grep auf hottinger/hbm/hbk: kein Treffer). Stufe ?, kein Gegenbeweis.
17. Identität: Name, Rechtsform (GmbH), Adresse stimmen laut Impressum (hbkworld.com/en/trust-centre/imprint: "Hottinger Brüel & Kjær GmbH", Darmstadt; "HBK GmbH is registered as a limited liability company in Darmstadt"); HRB-Nummer auf der Seite nicht angegeben (USt-ID DE 111 638 489). Altname Hottinger Baldwin Messtechnik GmbH auf hbm.com, gleiche Adresse. Konzernzugehörigkeit "Spectris" nicht belegt (Impressum nennt Hottinger Brüel & Kjær A/S, Virum, Dänemark).
Nicht verwendbare Aussagen (A, S, ?): Produktlinien-zu-Werk-Zuordnung (A); Elektronik/Netzteile vergossen (A); Wirtschaftsforum-Angaben (S); Rechtsstand 1980er-Patente (nicht belegt); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: ja (CRM-Zuordnung "HBM").

## 2) ASG Luftfahrttechnik und Sensorik GmbH, Weinheim
1. Firma: ASG Luftfahrttechnik und Sensorik GmbH, Weinheim
2. Segment: Electrical Insulation (Sensoren und Aktorik für Land-/Baumaschinen, Nutzfahrzeuge, E-Mobility)
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Junkersstr. 2, 69469 Weinheim (ein Standort), HRB 430526 AG Mannheim
5. Website: https://asg-weinheim.de
6. Was wird gebaut: Winkel-, Drehzahl-, Temperatur-, Neigungs-, Induktivsensoren, Fahrpedale (Stufe V, Startseite); Luftfahrtkomponenten (Ventile, Pumpen, Positionssensoren). Typisch vergossen: Drehzahl-, Induktiv-, Temperatursensoren, Fahrpedal-Sensorik (Stufe A, Block A, Sensoren rauer Einsatz Landmaschine).
7. Fertigung DE/AT/NL: Hoch, Stufe V. Historie nennt 2008 und 2010 den Ausbau "automatischer Fertigungslinien", Jobseite Mechatroniker und Mechaniker/Dreher; zusätzlich Sitzregel (Gerätebauer, ein Standort, kein Konzern, keine Auslagerungshinweise) erfüllt.
8. Verguss/Bonding (höchstes Bauteil): Hoch, Stufe A. Bauteile: Drehzahl-/Induktivsensoren Hoch (A); Temperatursensoren Hoch (A); Fahrpedal-/Hebelsensorik Hoch (A); Beschleunigungs-/Differenzdrucksensoren Mittel (A); Ventile/Handpumpen Niedrig (A).
9. Patentrecherche: Tina (a) Google Patents, Anmelder "ASG Luftfahrttechnik": etwa 46 Treffer gesamt (wie Tom); mit potting OR Vergussmasse OR vergossen OR Verguss OR "potting compound" OR encapsulated: 2 Treffer, beide "encapsulated switchgear" (DE19617193A1, DE4440281C2, Lichtbogen-Erkennung, kein Verguss im Sinn von Potting). US6531667B2 "Pedal displacement sensor" (Deere & Company und ASG, Priorität 2000, erteilt 2003-03-11) im Browser geöffnet: Status "Expired - Lifetime". Espacenet/DEPATISnet: Toms "keine Treffer" nicht erneut gefahren (Stufe S). Keine Treffer ist kein Gegenbeweis.
10. Einstufung Tom: interessant
11. Ampel (nur Tina): GRÜN, Tabellenzeile 4 (Fertigung Weinheim Stufe V/Sitzregel, Verguss Hoch Stufe A, kein Ausschluss, kein CRM-Bezug).
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: ASG Luftfahrttechnik und Sensorik GmbH, ASG Beteiligungs GmbH: kein Treffer)
13. Nachrecherche-Auftrag und Aktion: kein Gelb-Auftrag. Aktion: Freigabe durch Jey; Unterseite https://asg-weinheim.de/de/sensorik/ wurde von Tina nicht erneut geöffnet.
14. Quellen:
- https://asg-weinheim.de/ , Zitat: „Winkelsensoren, Drehzahlsensoren, Temperatursensoren, Fahrpedale, Neigungssensoren, Induktivsensoren“ (Browser gelesen, Abruf 2026-10-14)
- https://asg-weinheim.de/de/ueber_asg/historie.php , Zitat: „2008: Erweiterung der automatischen Fertigungslinien“ (Abruf 2026-10-14)
- https://asg-weinheim.de/de/ueber_asg/jobs.php , Zitat: „Mechaniker/Dreher (m/w/d)“ (Abruf 2026-10-14)
- https://asg-weinheim.de/de/footer/Impressum.php , Zitat: „Registergericht Mannheim HRB 430526“ (Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (alle vier).
15. Größe/Umsatz: rund 160 Mitarbeitende (Tom, Stufe S, nicht von Tina geprüft); Umsatz unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf asg/luftfahrt: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: Name, Rechtsform GmbH, Adresse Junkersstr. 2, 69469 Weinheim, HRB 430526 AG Mannheim stimmen laut Impressum (Tina im Browser gelesen). Vorgängername AEG Sensorsysteme GmbH (Historie), Gesellschafter ASG Beteiligungs GmbH (Historie 2002).
Nicht verwendbare Aussagen (A, S, ?): Vergusskomponenten (A); Mitarbeiterzahl (S); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: nein.

## 3) Heidelberg Engineering GmbH, Heidelberg
1. Firma: Heidelberg Engineering GmbH, Heidelberg
2. Segment: Electrical Insulation (Medizintechnik: Elektronik, Scanner, Sensorik)
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Max-Jarecki-Straße 8, 69115 Heidelberg; Fertigungsort Heidelberg nur aus Sitzregel (Stufe A)
5. Website: https://www.heidelbergengineering.com
6. Was wird gebaut: ophthalmologische Diagnosegeräte SPECTRALIS, ANTERION (OCT) (Stufe V). Typisch vergossen/verklebt: Steuer- und Netzteil-Elektronik, Scanner-/Galvo-Antriebe, Laser-/Kameramodule, Gehäusedichtungen (Stufe A, Endprodukt- und Medizintechnik-Regel).
7. Fertigung DE/AT/NL: Hoch, Stufe A (Sitzregel). "Entwicklung und Herstellung" (V) und Karriereseite "entwickelt, produziert und vertreibt" (V) belegen Eigenherstellung, aber keinen Ort; Gerätebauer mit eigenen Produkten, einem erkennbaren Standort (über 600 Mitarbeitende laut Karriereseite), keine Auslagerungshinweise gesehen.
8. Verguss/Bonding (höchstes Bauteil): Mittel, Stufe A. Steuerplatinen/Netzteile Mittel (A); Scanner-/Mikroantriebe Mittel (A); Laser-/Kameramodule Mittel (A); Gehäusedichtungen Mittel (A). Kleine Mengen sind kein Gegenargument.
9. Patentrecherche: Tina (a) Google Patents, Anmelder "Heidelberg Engineering" + potting OR Vergussmasse OR Verguss OR encapsulation OR adhesive OR sealing: 5 Treffer (wie Tom): WO2007138490A2 und US20120083691A1 (Photodynamische Therapie, "seal" medizinisch), US12318167B2 (OCT-Baugruppe, "sealed housing", 2025), DE10035835C2 (Med Laserzentrum Lübeck); kein Potting-Patent. Espacenet/DEPATISnet nicht erneut gefahren (Toms "keine Treffer" nur Stufe S).
10. Einstufung Tom: prüfenswert
11. Ampel (nur Tina): GRÜN, Tabellenzeile 4 (Fertigung Stufe A nach Sitzregel, Verguss Mittel Stufe A, kein Ausschluss, kein CRM-Bezug).
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: kein Treffer)
13. Nachrecherche-Auftrag und Aktion: kein Gelb-Auftrag. Optional vor Mailaussage: Produktions-/Montagestelle am Sitz im Jobportal https://heidelberg-engineering.job-shop.com/heidelberg-engineering/ (Kategorie Operations) belegen; Tina konnte die Jobliste nicht öffnen.
14. Quellen:
- https://www.heidelbergengineering.com/de-DE/ueber-uns , Zitat: „Entwicklung und Herstellung modernster ophthalmologischer Diagnosegeräte“ (Browser gelesen, Abruf 2026-10-14)
- https://heidelberg-engineering.job-shop.com/heidelberg-engineering/ , Zitat: „entwickelt, produziert und vertreibt nachhaltige Lösungen für die Augenheilkunde“ (Abruf 2026-10-14)
- https://www.heidelbergengineering.com/de-DE/rechtliches/impressum , Zitat: „Handelsregister: Mannheim, HRB 334163“ (Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (alle drei).
15. Größe/Umsatz: über 600 Mitarbeitende (Karriereseite, Stufe S, eine Quelle); Umsatz unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf heidelberg: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: Name, Rechtsform GmbH, Adresse Max-Jarecki-Straße 8, 69115 Heidelberg, Handelsregister Mannheim HRB 334163 laut Impressum (Tina im Browser gelesen). Tochter Munich Surgical Imaging (München) ist eine andere Einheit. Keine Verwechslung mit Heidelberg Instruments oder Heidelberger Druckmaschinen.
Nicht verwendbare Aussagen (A, S, ?): Fertigungsort Heidelberg (A, Sitzregel); alle Vergussbauteile (A); Mitarbeiterzahl (S); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: nein.

## 4) Heidelberg Instruments Mikrotechnik GmbH, Heidelberg
1. Firma: Heidelberg Instruments Mikrotechnik GmbH, Heidelberg
2. Segment: Electrical Insulation (Geräte-/Anlagenbau mit Elektronik, Laser- und Antriebsmodulen); nachrangig
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Mittelgewannweg 27, 69123 Heidelberg (Headquarters); Montage/Elektronikfertigung in Deutschland laut Karriereseite, Ortsnennung Heidelberg nur indirekt. Konzern LAB14 Group (Tochter der RSBG SE, Eigentümer RAG-Stiftung laut Karriereseite).
5. Website: https://heidelberg-instruments.com
6. Was wird gebaut: Laserlithografie-Systeme, Maskless Aligner (Stufe V, About Us). Typisch vergossen/verklebt: Steuer-/Netzteil-Elektronik, Antriebs- und Positioniermodule (Stufe A), Laser-/Optikmodule (Klebung, Stufe A).
7. Fertigung DE/AT/NL: Mittel, Stufe V/A. Konzern, daher keine Sitzregel. Karriereseite: "Head of Electronics Production, Germany" und "Industrial Mechanic, Germany" (Aufbau von Tischsystemen), Heidelberg als einziger deutscher Standort genannt ("headquarters in Heidelberg" und Zürich); das ist ein Mitarbeiterporträt, keine Stellenanzeige und nennt Heidelberg nicht wörtlich, daher nicht als V gewertet.
8. Verguss/Bonding (höchstes Bauteil): Mittel, Stufe A. Steuerelektronik/Netzteile Mittel (A); Linear-/Direktantriebe Mittel (A); Laser-/Optikmodule Niedrig bis Mittel (A); Gehäuse Niedrig (A).
9. Patentrecherche: Tina (a) Google Patents, Anmelder "Heidelberg Instruments" + potting OR Vergussmasse OR Verguss OR encapsulation OR adhesive OR sealing: 7 Treffer (wie Tom), alle Fremdanmelder (SwissLitho EP3047335B1, IBM US20170003602A1, EP2384456B1, Duerig); kein Potting-Treffer. Espacenet/DEPATISnet nicht erneut gefahren (Toms "keine Treffer" nur Stufe S).
10. Einstufung Tom: prüfenswert
11. Ampel (nur Tina): GELB, Tabellenzeile 5 (Fertigung DE belegt nur indirekt, Konzern, keine Sitzregel; Verguss Mittel A).
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: Firma, LAB14, RSBG SE, RAG-Stiftung: kein Treffer)
13. Nachrecherche-Auftrag und Aktion: Frage: Wird die Elektronik/Systemmontage am Standort Heidelberg gemacht (nicht bei Heidelberg Instruments Nano/Zürich oder anderer LAB14-Einheit)? Nachsehen: Jobportal "Jobs Germany & Worldwide" über https://heidelberg-instruments.com/career/ (Stellenanzeigen Elektronikfertigung, Montage, Industriemechaniker mit Ort Heidelberg). Zweitfrage optional: welche Baugruppen werden vergossen/verklebt. Aktion: Tom (Runde 1, Browser).
14. Quellen:
- https://heidelberg-instruments.com/legal-notice/ , Zitat: „Heidelberg Instruments Mikrotechnik GmbH Mittelgewannweg 27 69123 Heidelberg“ (Browser gelesen, Abruf 2026-10-14)
- https://heidelberg-instruments.com/about-us/ , Zitat: „Heidelberg Instruments is part of the LAB14 Group“ (Abruf 2026-10-14)
- https://heidelberg-instruments.com/career/ , Zitat: „Head of Electronics Production, Germany“ (Mitarbeiterporträt, Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (alle drei; nur Gelb, keine Grün-Aussage).
15. Größe/Umsatz: mehr als 380 Mitarbeitende an acht Standorten (Karriereseite, Stufe S); Umsatz unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf heidelberg/lab14: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: Name, Rechtsform GmbH, Adresse Mittelgewannweg 27, 69123 Heidelberg, Handelsregister Mannheim HRB 333834 laut Legal Notice (Tina im Browser gelesen). Keine Verwechslung mit Heidelberg Engineering oder Heidelberger Druckmaschinen.
Nicht verwendbare Aussagen (A, S, ?): Fertigung Heidelberg (nur indirekt); alle Vergussbauteile (A); Mitarbeiterzahl (S); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: nein.

## 5) Caterpillar Energy Solutions GmbH (MWM), Mannheim
1. Firma: Caterpillar Energy Solutions GmbH (Marken MWM und Cat), Mannheim
2. Segment: Electrical Insulation (Zündsysteme, Sensorik, Steuerungs- und Generatorelektronik an Gasmotoren und Gensets)
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Carl-Benz-Strasse 1, 68167 Mannheim (Sitz; Gas Center of Excellence am Standort Mannheim). Konzern Caterpillar Inc.
5. Website: https://caterpillar-energy-solutions.de/en/
6. Was wird gebaut: Gasmotoren, Gensets, Gaskraftwerke, BHKW (Stufe V, Firmenseite). Typisch vergossen/abgedichtet (auch zugekauft): Zündspulen/-module, Motorsteuergerät, Sensorik (Stufe A, Block A), Generatorwicklung, Schaltschrank-/Genset-Steuerung (Stufe A).
7. Fertigung DE/AT/NL: Hoch, Stufe V. Seite Operations: Mannheim zum "global Gas Center of Excellence" ausgebaut, bündelt Entwicklung und Produktion; "In-house manufacturing of all key components". Konzernfirma, aber Werk Mannheim ausdrücklich genannt (Toms Stufe A für die Werkzuordnung ist damit V).
8. Verguss/Bonding (höchstes Bauteil): Hoch, Stufe A. Zündspulen/-module Hoch (A); Motorsteuergerät/Sensorik Hoch (A); Genset-Steuerung Mittel (A); Generatorwicklung Mittel (A). Patent EP2993361A1 (Schraubensicherung mit Potting-Material) ist nur ein schwaches Zusatzsignal (siehe Feld 9).
9. Patentrecherche: Tina (a) Google Patents, EP2993361A1 im Browser geöffnet: "Method and device for locking screws", Anmelder Caterpillar Energy Solutions GmbH, Priorität 2014-09-02, veröffentlicht 2016-03-09, Status "Withdrawn" (zurückgenommen; Toms "Erteilungsstand nicht gelesen" geklärt, B1-Familie von Tina nicht gesehen); Anspruch 3 "molding potting material (48) into the clearances". Das Patent betrifft Schraubensicherung, nicht Elektronik-Verguss. Espacenet/DEPATISnet und Toms Trefferlisten (ca. 250 breit) nicht erneut gefahren (Stufe S).
10. Einstufung Tom: interessant
11. Ampel (nur Tina): GRÜN, Tabellenzeile 4 (Fertigung Mannheim Stufe V, Verguss Hoch Stufe A, kein Ausschluss, kein CRM-Bezug auch über Caterpillar Inc.).
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: Caterpillar Energy Solutions GmbH, MWM GmbH, Caterpillar Inc., Caterpillar: kein Treffer)
13. Nachrecherche-Auftrag und Aktion: kein Gelb-Auftrag. Aktion: Freigabe durch Jey.
14. Quellen:
- https://caterpillar-energy-solutions.de/en/success-factors/operations/ , Zitat: „expanded the Mannheim location to become a global Gas Center of Excellence“ (Browser gelesen, Abruf 2026-10-14)
- https://caterpillar-energy-solutions.de/en/ , Zitat: „manufactures gas engines, electricity power plants, as well as CHP plants“ (Abruf 2026-10-14)
- https://caterpillar-energy-solutions.de/en/imprint/ , Zitat: „Registered office and register court Mannheim, HRB 703305“ (Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (alle drei; Toms zwei Zitate der Startseite ebenfalls bestätigt).
15. Größe/Umsatz: unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf caterpillar/mwm: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: Caterpillar Energy Solutions GmbH, Carl-Benz-Strasse 1, 68167 Mannheim, Registergericht Mannheim HRB 703305 laut Impressum (Tina im Browser gelesen; schließt Toms offene Lücke). Vorgängername MWM GmbH (Stufe S).
Nicht verwendbare Aussagen (A, S, ?): alle Vergussbauteile (A); Patent als Signal für Elektronik-Verguss (nicht tragfähig, zurückgenommen); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: nein.

## 6) Roche Diagnostics GmbH, Mannheim
1. Firma: Roche Diagnostics GmbH (RDG) und Roche Diabetes Care GmbH (RDC), Standort Mannheim
2. Segment: Electrical Insulation (Medizintechnik: Instrumente, Sensorik, Pumpen- und Messgeräte-Elektronik)
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Standort Mannheim (Sandhofer Straße 116, 68305 Mannheim laut roche.de für Roche Diagnostics Deutschland GmbH); fertigende Einheiten RDG (Instrumente, Systeme, Reagenzien) und RDC (Insulinpumpen, Blutzuckermessgeräte). Konzern Roche.
5. Website: https://www.roche.de (Anbieter laut Impressum: Roche Deutschland Holding GmbH, nicht RDG)
6. Was wird gebaut: Instrumente und Systeme für In-vitro-Diagnostik (RDG), Insulinpumpen, Infusionssets, Teststreifen, Kassetten, Blutzucker-Messgeräte (RDC) (Stufe V, Umwelterklärung 2025 Standort Mannheim, als ENTWURF gekennzeichnet). Typisch vergossen: Elektronik/Sensorik der Analysegeräte, Pumpen-/Messgeräte-Elektronik (Stufe A, Medizintechnik-Regel).
7. Fertigung DE/AT/NL: Hoch, Stufe V. Umwelterklärung: "Hier erfolgt die Entwicklung und Produktion spezifischer Reagenzien, Tests, Instrumente und Systeme" (RDG) und RDC Entwicklung und Produktion von Insulinpumpen und Messgeräten in Mannheim. Quelle ist ein ENTWURF (Vorbehalt).
8. Verguss/Bonding (höchstes Bauteil): Hoch, Stufe A. Blutzuckermessgeräte-/Pumpen-Elektronik Hoch (A); Analysegeräte-Sensorik/Optikeinheit Hoch (A; Patent nur Zusatzsignal); Steuer-/Netzteil-Elektronik Mittel (A); Teststreifen/Kassetten Niedrig (A).
9. Patentrecherche: Tina (a) Google Patents, EP2151680A1 im Browser geöffnet: "Assembly method for manufacturing an analysis system", Anmelder F. Hoffmann-La Roche AG und Roche Diagnostics GmbH (Tom nannte nur RDG), Priorität 2008-08-05, veröffentlicht 2010-02-10, Status "Withdrawn" (zurückgenommen; Tom: "Rechtsstand nicht sichtbar"). Der Potting-Satz selbst wurde von Tina nicht im Volltext gesucht. Espacenet/DEPATISnet nicht erneut gefahren (Stufe S).
10. Einstufung Tom: interessant
11. Ampel (nur Tina): GRÜN, Tabellenzeile 4 (Fertigung Mannheim Stufe V, Verguss Hoch Stufe A, kein Ausschluss, kein CRM-Bezug). Vorbehalt: tragende Quelle ist ein Entwurf, Identität ohne HRB.
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: Roche Diagnostics GmbH, Roche Diabetes Care GmbH, Roche Diagnostics Deutschland GmbH, F. Hoffmann-La Roche: kein Treffer; der Treffer "Roche" in kundendatenbank_export.txt Z. 11 ist ein Teilwort in einer Opportunity-Beschreibung, kein Firmenname, Tom korrekt)
13. Nachrecherche-Auftrag und Aktion: kein Gelb-Auftrag. Empfehlung: Handelsregisterauszug RDG (Sitz Mannheim) und finale (nicht-Entwurf) Umwelterklärung gegenlesen, bevor eine Mailaussage über Fertigung erfolgt.
14. Quellen:
- https://assets.cwp.roche.com/f/94122/x/3d0f0aaec4/umwelterklarung-2025-mannheim.pdf , Seite 9, Zitat: „Entwicklung und Produktion spezifischer Reagenzien, Tests, Instrumente und Systeme“ (Browser gelesen, Abruf 2026-10-14)
- https://assets.cwp.roche.com/f/94122/x/3d0f0aaec4/umwelterklarung-2025-mannheim.pdf , Seite 9, Zitat: „Entwicklung und Produktion von Insulinpumpen, Infusionssets, Teststreifen, Kassetten“ (Abruf 2026-10-14)
- https://www.roche.de/impressum , Zitat: „Roche Diagnostics Deutschland GmbH Sandhofer Straße 116 68305 Mannheim“ (Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (Umwelterklärung beide Zitate sinngemäß wörtlich auf Seite 9; Impressum ja).
15. Größe/Umsatz: unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf roche: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: Name "Roche Diagnostics GmbH" mit Standort Mannheim laut Umwelterklärung (Deckblatt/Seite 9, ENTWURF); Rechtsform GmbH, aber Register/HRB der RDG nicht belegt. roche.de/diagnostics.roche.com verweisen auf das Impressum der Roche Deutschland Holding GmbH (Grenzach-Wyhlen, HRB 412761 Freiburg); Mannheim nur als Kontaktadresse der Roche Diagnostics Deutschland GmbH. Abweichung zu Toms Feld 5/13 (Impressum RDG).
Nicht verwendbare Aussagen (A, S, ?): alle Vergussbauteile (A); Rechtsform/HRB der RDG (offen); Patent-Signal (zurückgenommen); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: ja (Entwurfsquelle, Identität ohne Register).

## 7) Heidelberger Druckmaschinen AG, Wiesloch-Walldorf (Tochter Amperfied GmbH)
1. Firma: Heidelberger Druckmaschinen AG (Hauptwerk Wiesloch-Walldorf); Tochter Amperfied GmbH (Wallbox) separat
2. Segment: Electrical Insulation (Antriebe, Steuerungen, Sensorik der Druckmaschinen); E-Mobility Potting nur über Amperfied (aktuell nicht belegt)
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Sitz Kurfürsten-Anlage 52-60, 69115 Heidelberg; Hauptwerk Gutenbergring, 69168 Wiesloch(-Walldorf). Weitere Werke: Amstetten, Brandenburg, Weiden, Ludwigsburg, Kumanovo, Shanghai u. a.
5. Website: https://www.heidelberg.com
6. Was wird gebaut: Druckmaschinen (Konzern mit mehreren Werken); Wandladestationen AMPERFIED, produziert in Wiesloch-Walldorf laut Pressemeldung 2022 (Stufe V für 2022, für heute nicht belegt). Typisch vergossen/abgedichtet: Maschinen-Antriebe, Steuerungen, Sensoren (Stufe A, Endprodukt-Regel Maschinen); Wallbox-Elektronik (Stufe A, falls aktuell produziert).
7. Fertigung DE/AT/NL: Hoch, Stufe V. Standortseite (Stand 2026): "Heidelberger Druckmaschinen AG - Hauptwerk, F&E, Verwaltung", Wiesloch. Welche Produktlinie dort gebaut wird, ist nicht einzeln belegt; Wallbox-Fertigung heute offen (Amperfied-Seite 2026 betont Betriebsführung und Herstellerunabhängigkeit).
8. Verguss/Bonding (höchstes Bauteil): Mittel, Stufe A. Druckmaschinen-Antriebe/Steuerungen/Sensoren Mittel (A); Kabeldurchführungen und Piezo-Sensoren mit Potting in eigenen Patenten (Zusatzsignal, siehe Feld 9); Wallbox-Elektronik Hoch (A) nur wenn aktuell gefertigt (nicht belegt); Gehäuse Niedrig (A).
9. Patentrecherche: Tina (a) Google Patents, Anmelder "Heidelberger Druckmaschinen" + "potting compound" OR Vergussmasse OR "potting material" OR "cast resin" OR Giessharz: 6 Treffer. Davon DE102006050541A1 (Bogenförderung, Priorität 2005, Piezo-Element-Stapel von "potting compound (53)" umgeben) und EP0297307B1 (Kabeldurchführung, Priorität 1987, Potting als Alternative), DE3744098C2 (1987, Gehäuseschalen mit Potting). Toms Espacenet-Eintrag "DE102006050541A1 ohne Verguss-Bezug" ist damit falsch. Rechtsstand dieser Patente: auf der Liste nicht sichtbar. Anmelder "Amperfied" Google Patents: keine Treffer. Espacenet/DEPATISnet nicht erneut gefahren (Stufe S).
10. Einstufung Tom: interessant
11. Ampel (nur Tina): GRÜN, Tabellenzeile 4 (Fertigung Hauptwerk Wiesloch Stufe V, Verguss Mittel Stufe A, kein Ausschluss, kein CRM-Bezug). Vorbehalt: Konzern mit mehreren Werken, Verguss nur aus Produkttyp.
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: Heidelberger Druckmaschinen AG, Amperfied GmbH: kein Treffer)
13. Nachrecherche-Auftrag und Aktion: kein Gelb-Auftrag. Offene Zusatzfrage aus Toms Auftrag: Wird die Wallbox 2026 noch in Wiesloch-Walldorf gefertigt? Ergebnis nicht gefunden (amperfied.de/Presse 2026 nennt nur Betriebsführung/Ladeinfrastruktur). Für Mailaussage nur über Druckmaschinen/Endprodukt formulieren.
14. Quellen:
- https://www.heidelberg.com/global/de/about_heidelberg/company/production_sites/our_sites.jsp , Zitat: „Heidelberger Druckmaschinen AG - Hauptwerk, F&E, Verwaltung“ (Wiesloch, Browser gelesen, Abruf 2026-10-14)
- https://www.heidelberg.com/global/de/global_content/legal_notices.jsp , Zitat: „Mannheim HRB 330004“ (Abruf 2026-10-14)
- https://www.heidelberg.com/global/de/about_heidelberg/press_relations/press_release/press_release_details/press_release_192064.jsp , Zitat: „Produziert wird die Wandladestation am Standort Wiesloch-Walldorf.“ (Pressemeldung 21.09.2022, Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (alle drei).
15. Größe/Umsatz: unbekannt
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf heidelberger/amperfied: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: Heidelberger Druckmaschinen AG, Kurfürsten-Anlage 52-60, 69115 Heidelberg, Handelsregister Mannheim HRB 330004 laut Impressum (Tina im Browser gelesen). Amperfied GmbH ist eigene Einheit: Gutenbergring 20, 69190 Walldorf, HRB 740405 Amtsgericht Mannheim (amperfied.de/amperfied-impressum). Keine Verwechslung mit Heidelberg Engineering, Heidelberg Instruments.
Nicht verwendbare Aussagen (A, S, ?): Verguss der Maschinenelektronik (A); Wallbox-Fertigung aktuell (offen); electrive-Artikel (S); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: ja (Konzern mit vielen Werken, Verguss nur aus Produkttyp, Wallbox-Status offen).

## 8) John Deere GmbH & Co. KG, Werk Mannheim (Konzern Deere & Company)
1. Firma: John Deere Werk Mannheim (Rechtseinheit laut Vorgabe "John Deere GmbH & Co. KG", nicht bestätigt)
2. Segment: Electrical Insulation (Traktor-Elektronik, Sensoren, Beleuchtung, künftig E-Antriebe)
3. Gebiet: Baden-Württemberg
4. Sitz und Fertigungsort: Traktorenwerk Mannheim (topagrar 2023); Impressum deere.de nennt als Anbieter John Deere Walldorf International GmbH, John-Deere-Straße 1, 69190 Walldorf
5. Website: https://www.deere.de
6. Was wird gebaut: Traktoren, etwa 40.000 pro Jahr in Mannheim, Entwicklung der mittleren Traktoren (Stufe V, topagrar 24.03.2023, älter als sechs Monate). Typisch vergossen/verklebt: ECUs, Sensoren, LED-Beleuchtung, Aktoren, Kabel/Stecker (Stufe A, Endprodukt-Regel, Block A).
7. Fertigung DE/AT/NL: Hoch, Stufe V. Werk Mannheim belegt, aber nur durch eine Quelle von 2023 (Neuprüfung fällig); Zuordnung der Elektronikbaugruppen zum Werk Mannheim nicht belegt (A).
8. Verguss/Bonding (höchstes Bauteil): Hoch, Stufe A. Steuergeräte/ECUs Hoch (A); Sensorik Hoch (A); LED-Beleuchtung Hoch (A); E-Antrieb künftig Hoch (A); Kabelbäume/Stecker Mittel (A); Mechanik/Hydraulik Niedrig (A).
9. Patentrecherche: Tina (a) Google Patents, Anmelder "Deere" + "potting compound": etwa 18 Treffer, u. a. DE102025131332A1 "Non-insulated directly cooled silicon module" (Priorität 2024-09-30, veröffentlicht 2026-04-02), AU2025210867A1 Sämaschinen-Sensor ("potting compound"), DE102025112904A1 Connector adapter (epoxy resin or potting compound, 2025), EP4642177A1 Elektronikbaugruppe mit Dichtung (2025). Toms "keine Treffer" lag an der Anmelder-Schreibweise ("Deere & Company" als Phrase). Anmelder ist Deere & Company (USA), nicht die Mannheimer Einheit. Espacenet/DEPATISnet nicht erneut gefahren (Stufe S).
10. Einstufung Tom: interessant
11. Ampel (nur Tina): GELB, Tabellenzeile 2 (Identität nicht belegt: Impressum deere.de nennt John Deere Walldorf International GmbH, Walldorf; "John Deere GmbH & Co. KG" und die fertigende Rechtseinheit des Werks Mannheim sind nicht belegt).
12. CRM-Status: neu (crm_abgleich.py 2026-10-14: John Deere GmbH & Co. KG, John Deere Walldorf International GmbH, Deere & Company, John Deere: kein Treffer; kein Konzernbezug)
13. Nachrecherche-Auftrag und Aktion: Frage: Wie lautet die juristische Einheit des Traktorenwerks Mannheim (Name, Rechtsform, Adresse, HRB) und ist sie von John Deere Walldorf International GmbH verschieden? Nachsehen: Handelsregister/Unternehmensregister (Mannheim), Werksseite John Deere Mannheim, Konzernabschluss-Dateien. Zusatzfrage: aktuelle Quelle (2026) zur Fertigung in Mannheim. Aktion: Tom (Runde 1, Browser).
14. Quellen:
- https://www.deere.de/de/impressum/ , Zitat: „John Deere Walldorf International GmbH“ (Impressum, Browser gelesen, Abruf 2026-10-14)
- https://www.topagrar.com/technik/news/john-deere-baut-zweimillionsten-traktor-in-mannheim-13342787.html , Zitat: „rund 3.300 Mitarbeiter etwa 40.000 Traktoren pro Jahr“ (Artikel 24.03.2023, Abruf 2026-10-14)
- https://patents.google.com/?assignee=Deere&q=%22potting+compound%22 , Zitat: „support plate 223 can be made of epoxy resin or potting compound“ (DE102025112904A1, Abruf 2026-10-14)
- Zitat im Browser bestätigt: ja (Toms topagrar-Zitate ebenfalls bestätigt).
15. Größe/Umsatz: etwa 3.300 Mitarbeitende in Mannheim (topagrar 2023, eine Quelle)
16. Wettbewerbereinsatz: kein Hinweis gefunden (Tina: wettbewerber_referenzen.md per grep auf deere: kein Treffer; Toms WebSearch nicht wiederholt). Stufe ?, kein Gegenbeweis.
17. Identität: NICHT belegt. Impressum deere.de: John Deere Walldorf International GmbH, John-Deere-Straße 1, 69190 Walldorf, HRB 743035 Amtsgericht Mannheim. Toms Rechtsform "John Deere GmbH & Co. KG" (Lobbyregister-Dateiname, Stufe S) wurde nicht bestätigt. Konzern Deere & Company (USA) getrennt.
Nicht verwendbare Aussagen (A, S, ?): Rechtsform/fertigende Einheit (S/?); Elektronik im Werk Mannheim (A); Fertigungsquelle von 2023 (Aktualität); Wettbewerbereinsatz (?). Datum der Verifikation: 2026-10-14. Stichprobe für Jey: ja (Identität).

## Zusammenfassung
Grün: 2 ASG, 3 Heidelberg Engineering, 5 Caterpillar Energy Solutions, 6 Roche Diagnostics, 7 Heidelberger Druckmaschinen. Gelb: 1 HBK (Zeile 3, CRM "HBM"), 4 Heidelberg Instruments (Zeile 5), 8 John Deere (Zeile 2). Rot: keine.

## Beanstandungen an Tom
- Nr. 1 HBK: CRM-Treffer "HBM" (Z. 989) übersehen, obwohl Altmarke; Patent DE10350724B4 ist erloschen (nicht nur "erteilt"); Zitat zum Patent nicht wörtlich auf der B4-Seite.
- Nr. 5 Caterpillar: Patent EP2993361A1 ist zurückgenommen und betrifft Schraubensicherung, deshalb nicht als "Hoch (V)" Bauteilbeleg; Werkzuordnung Mannheim ist V (Operations-Seite), Impressum/HRB nachgetragen.
- Nr. 6 Roche: Patent EP2151680A1 zurückgenommen, Mitanmelder F. Hoffmann-La Roche AG fehlte; roche.de gehört der Roche Deutschland Holding GmbH; Aussage "RDD in RDG fusioniert" falsch (laut Dokument wurde die RDCD in die RDD fusioniert).
- Nr. 7 Heidelberger Druck: DE102006050541A1 fälschlich "ohne Verguss-Bezug" (Potting im Anspruch); Fertigungsquelle von 2022 durch Standortseite 2026 ersetzt; Impressum/HRB nachgetragen.
- Nr. 8 John Deere: Google-Patents-Suche mit falscher Anmelder-Schreibweise (18 Treffer mit "Deere"); Rechtsform/Identität nicht belegt, Impressum nennt John Deere Walldorf International GmbH.
- Nr. 4 Heidelberg Instruments: Karriereseite mit Elektronikproduktion in Deutschland übersehen (Hinweis, nicht V).
- Allgemein: batch_check.py zählte Feld 9 als vollständig, obwohl DEPATISnet-Abfragen nur Abstract-Feld nutzten (Toms eigene Einschränkung).

## Einschränkungen
- Espacenet nur für HBK, DEPATISnet nie selbst wiederholt; Toms Trefferlisten dort nicht nachvollzogen (Stufe S). Eigene Patentsuche je Firma nur in Google Patents (plus Einzelseiten).
- Roche-Umwelterklärung ist ein ENTWURF; roche.de/diagnostics.roche.com liefern kein Impressum der RDG; HBK-Impressum ohne HRB; Heidelberg-Engineering-Jobliste (Operations) und ASG-Unterseite /sensorik/ nicht geöffnet; Caterpillar-Zündmodul-Verguss und Wallbox-Status bei Amperfied nicht belegbar.
- Wettbewerbereinsatz: nur grep in wettbewerber_referenzen.md, keine eigenen Websuchen (WebSearch in diesem Lauf nicht genutzt).
- Cookie-Banner (hbm.com, Heidelberg Engineering Karriereseite) abgelehnt; Captcha und Login-Wand traten nicht auf.
